# GORAID | GitHub upload and deployment guide

This repository contains the GORAID Laravel 12 ride-booking starter project and a separate MySQL SQL export.

## Important: GitHub is not Laravel hosting

Uploading this code to GitHub stores and versions the source code. It does **not** run the Laravel/PHP application. To make GORAID publicly live, deploy it to a PHP 8.2+ host with a MySQL/MariaDB database (for example, a Laravel-capable shared host or a supported application platform). GitHub Pages cannot run Laravel/PHP or MySQL.

## 1. Create a GitHub repository

1. Sign in at https://github.com.
2. Click **New repository**.
3. Repository name: `GORAID`.
4. Choose **Private** while developing, or **Public** if you want the code visible to everyone.
5. Do not initialize it with a README, `.gitignore`, or license because this package already includes project files.
6. Create the repository.

## 2. Upload the project

1. Extract this ZIP on your computer.
2. Open the extracted `GORAID_Laravel` folder.
3. Upload the *contents* of that folder to the new GitHub repository (not the outer folder itself). Include `artisan`, `app`, `bootstrap`, `config`, `database`, `public`, `resources`, `routes`, `storage`, `composer.json`, `composer.lock` if generated, and `.env.example`.
4. Also upload `GORAID_Database.sql` and this guide at the repository root.
5. Commit the upload with a message such as `Initial GORAID project upload`.

**Never upload `.env`, `vendor/`, real passwords, API keys, or production database credentials.** The included `.gitignore` excludes `.env` and `vendor`.

## 3. Configure the live server

On your chosen Laravel/PHP hosting provider:

1. Create a MySQL database and database user.
2. Set the document/web root to the Laravel project's `public` directory. Do not expose the project root, `.env`, `storage`, or `vendor` publicly.
3. Set the production environment variables in the host dashboard or server `.env`:
   - `APP_NAME=GORAID`
   - `APP_ENV=production`
   - `APP_DEBUG=false`
   - `APP_URL=https://YOUR-DOMAIN`
   - `DB_CONNECTION=mysql`
   - `DB_HOST`, `DB_PORT`, `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD` from the host
   - `SESSION_DRIVER=file` (or a correctly configured persistent store)
   - `CACHE_STORE=file`
   - `QUEUE_CONNECTION=sync`
4. Generate a unique production `APP_KEY` using `php artisan key:generate` on the server, or the host's Laravel deployment tooling. Do not reuse a public/example key.
5. Install Composer dependencies on the server with `composer install --no-dev --optimize-autoloader`.
6. For a fresh database, use **one** database setup method:
   - Recommended: `php artisan migrate --seed`; OR
   - Import `GORAID_Database.sql` into an empty database.

Do not import the SQL export and then run migrations against the same already-populated database. The SQL export drops/recreates its listed tables, so only import it into an empty database or a disposable database after a backup.

Then run, as appropriate for the host:

```bash
php artisan storage:link
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

Set `APP_DEBUG=false`, enable HTTPS, configure backups, and test registration, login, booking, cancellation, driver approval, and admin permissions before sharing the site publicly.

## 4. Demo accounts

The included seed data creates development accounts for these email addresses:

- Admin: `admin@goraid.pk`
- Driver: `driver@goraid.pk`
- Customer: `customer@goraid.pk`

Check the local seeder or test the credentials locally before relying on them. Change or remove all demo accounts before production. Never use demo credentials for a public deployment.

## 5. Current integration limitations

This starter currently uses manually entered pickup/drop-off locations and an estimated distance entered by the user. Live Google Maps routing/Places autocomplete is not enabled. Cash-after-ride is the default payment flow; JazzCash/Easypaisa require real gateway integration and verified callbacks before accepting live payments. Configure email/SMS, monitoring, backups, HTTPS, and perform security/acceptance testing before production use.

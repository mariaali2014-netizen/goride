<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\DriverController;
use App\Http\Controllers\ContactController;

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/about', fn() => view('pages.about'))->name('about');
Route::get('/contact', [ContactController::class, 'create'])->name('contact');
Route::post('/contact', [ContactController::class, 'store'])->name('contact.store');
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.store');
Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
Route::post('/register', [AuthController::class, 'register'])->name('register.store');
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/bookings/create', [BookingController::class, 'create'])->name('bookings.create');
    Route::post('/bookings', [BookingController::class, 'store'])->name('bookings.store');
    Route::get('/bookings/{booking}', [BookingController::class, 'show'])->name('bookings.show');
    Route::post('/bookings/{booking}/cancel', [BookingController::class, 'cancel'])->name('bookings.cancel');
});

Route::middleware(['auth','role:driver'])->prefix('driver')->name('driver.')->group(function () {
    Route::post('/availability', [DriverController::class, 'availability'])->name('availability');
    Route::post('/bookings/{booking}/accept', [DriverController::class, 'accept'])->name('accept');
    Route::post('/bookings/{booking}/reject', [DriverController::class, 'reject'])->name('reject');
    Route::post('/bookings/{booking}/start', [DriverController::class, 'start'])->name('start');
    Route::post('/bookings/{booking}/complete', [DriverController::class, 'complete'])->name('complete');
});

Route::middleware(['auth','role:admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', [AdminController::class, 'index'])->name('dashboard');
    Route::get('/bookings', [AdminController::class, 'bookings'])->name('bookings');
    Route::get('/drivers', [AdminController::class, 'drivers'])->name('drivers');
    Route::post('/drivers/{driver}/approve', [AdminController::class, 'approveDriver'])->name('drivers.approve');
    Route::get('/vehicles', [AdminController::class, 'vehicles'])->name('vehicles');
    Route::post('/vehicles', [AdminController::class, 'storeVehicle'])->name('vehicles.store');
    Route::delete('/vehicles/{vehicle}', [AdminController::class, 'deleteVehicle'])->name('vehicles.delete');
    Route::get('/messages', [AdminController::class, 'messages'])->name('messages');
    Route::get('/fares', [AdminController::class, 'fares'])->name('fares');
    Route::post('/fares', [AdminController::class, 'updateFares'])->name('fares.update');
});

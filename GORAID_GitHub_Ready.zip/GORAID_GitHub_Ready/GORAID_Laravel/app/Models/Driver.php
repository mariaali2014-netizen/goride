<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Driver extends Model {
    protected $fillable = ['user_id','cnic','license_path','vehicle_id','province_id','city_id','is_approved','is_online','rating'];
    protected function casts(): array { return ['is_approved'=>'boolean','is_online'=>'boolean','rating'=>'decimal:2']; }
    public function user(){ return $this->belongsTo(User::class); }
    public function vehicle(){ return $this->belongsTo(Vehicle::class); }
    public function bookings(){ return $this->hasMany(Booking::class); }
}

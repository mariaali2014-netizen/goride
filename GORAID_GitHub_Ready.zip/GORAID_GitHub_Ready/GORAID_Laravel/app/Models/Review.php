<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Review extends Model { protected $fillable=['booking_id','user_id','driver_id','rating','comment']; }

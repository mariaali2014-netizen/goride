<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class VehicleCategory extends Model {
 protected $fillable=['name','slug','description','base_fare','per_km_rate','minimum_fare','capacity','image','is_active'];
 protected function casts(): array { return ['base_fare'=>'decimal:2','per_km_rate'=>'decimal:2','minimum_fare'=>'decimal:2','is_active'=>'boolean']; }
 public function vehicles(){return $this->hasMany(Vehicle::class);}
}

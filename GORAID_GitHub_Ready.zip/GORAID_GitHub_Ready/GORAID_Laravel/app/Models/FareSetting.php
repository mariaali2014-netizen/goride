<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class FareSetting extends Model { protected $fillable=['key','value','label']; }

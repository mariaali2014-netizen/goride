<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Vehicle extends Model {
 protected $fillable=['vehicle_category_id','name','registration_number','capacity','image','is_active'];
 protected function casts(): array { return ['is_active'=>'boolean']; }
 public function category(){return $this->belongsTo(VehicleCategory::class,'vehicle_category_id');}
}

<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Location extends Model { protected $fillable=['city_id','name','location_type']; public function city(){return $this->belongsTo(City::class);} }

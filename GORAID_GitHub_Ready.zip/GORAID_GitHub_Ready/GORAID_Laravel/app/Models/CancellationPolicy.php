<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class CancellationPolicy extends Model { protected $fillable=['free_cancel_minutes','charge_after_acceptance','fixed_charge','is_active']; protected function casts(): array{return ['charge_after_acceptance'=>'boolean','is_active'=>'boolean'];} }

<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Booking extends Model {
 protected $fillable=['booking_code','user_id','driver_id','vehicle_category_id','pickup_location','dropoff_location','pickup_date','pickup_time','distance_km','estimated_fare','final_fare','status','payment_method','payment_status','notes','cancel_reason'];
 protected function casts(): array { return ['pickup_date'=>'date','distance_km'=>'decimal:2','estimated_fare'=>'decimal:2','final_fare'=>'decimal:2']; }
 public function user(){return $this->belongsTo(User::class);}
 public function driver(){return $this->belongsTo(Driver::class);}
 public function category(){return $this->belongsTo(VehicleCategory::class,'vehicle_category_id');}
 public function histories(){return $this->hasMany(BookingStatusHistory::class);}
 public function payments(){return $this->hasMany(Payment::class);}
}

<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Payment extends Model {
 protected $fillable=['booking_id','amount','method','status','transaction_reference','paid_at'];
 protected function casts(): array { return ['amount'=>'decimal:2','paid_at'=>'datetime']; }
}

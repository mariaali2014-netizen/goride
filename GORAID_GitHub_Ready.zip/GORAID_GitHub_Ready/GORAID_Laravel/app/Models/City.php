<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class City extends Model { protected $fillable=['province_id','name','is_capital']; protected function casts(): array{return ['is_capital'=>'boolean'];} public function province(){return $this->belongsTo(Province::class);} public function locations(){return $this->hasMany(Location::class);} }

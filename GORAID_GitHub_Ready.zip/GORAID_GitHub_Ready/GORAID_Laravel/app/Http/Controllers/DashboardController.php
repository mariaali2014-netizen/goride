<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Booking;
use App\Models\VehicleCategory;
class DashboardController extends Controller {
 public function index(Request $r){
  $u=$r->user();
  if($u->role==='admin') return redirect()->route('admin.dashboard');
  if($u->role==='driver') {
   $driver=$u->driver;
   $available=Booking::where('status','pending')->latest()->get();
   $mine=$driver ? $driver->bookings()->with('user','category')->latest()->get() : collect();
   return view('dashboard.driver',['driver'=>$driver,'available'=>$available,'bookings'=>$mine]);
  }
  return view('dashboard.customer',['bookings'=>$u->bookings()->with('category','driver.user')->latest()->get()]);
 }
}

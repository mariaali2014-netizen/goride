<?php
namespace App\Http\Controllers;
use App\Models\ContactMessage;
use Illuminate\Http\Request;
class ContactController extends Controller {
 public function create(){return view('pages.contact');}
 public function store(Request $r){$d=$r->validate(['name'=>'required|string|max:120','email'=>'required|email|max:190','phone'=>'nullable|string|max:30','subject'=>'required|string|max:190','message'=>'required|string|max:3000']);ContactMessage::create($d);return back()->with('success','Your message has been sent.');}
}

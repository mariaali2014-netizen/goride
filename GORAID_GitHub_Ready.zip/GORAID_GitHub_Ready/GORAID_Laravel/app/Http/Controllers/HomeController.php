<?php
namespace App\Http\Controllers;
use App\Models\VehicleCategory;
class HomeController extends Controller {
 public function index(){return view('home',['categories'=>VehicleCategory::where('is_active',true)->get()]);}
}

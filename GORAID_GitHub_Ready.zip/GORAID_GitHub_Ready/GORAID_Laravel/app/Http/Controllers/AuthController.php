<?php
namespace App\Http\Controllers;
use App\Models\User;
use App\Models\Driver;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;
class AuthController extends Controller {
 public function showLogin(){return view('auth.login');}
 public function showRegister(){return view('auth.register');}
 public function login(Request $r){
  $data=$r->validate(['email'=>'required|email','password'=>'required|string']);
  if(!Auth::attempt($data,$r->boolean('remember'))){return back()->withErrors(['email'=>'Email or password is incorrect.'])->onlyInput('email');}
  $r->session()->regenerate(); return redirect()->intended(route('dashboard'));
 }
 public function register(Request $r){
  $data=$r->validate(['name'=>'required|string|max:120','email'=>'required|email|unique:users,email','phone'=>'required|string|max:30','password'=>['required','confirmed',Password::min(8)] ,'role'=>'required|in:customer,driver']);
  $user=User::create([...$data,'password'=>Hash::make($data['password'])]);
  if($data['role']==='driver'){ Driver::create(['user_id'=>$user->id,'is_approved'=>false,'is_online'=>false]); }
  Auth::login($user); $r->session()->regenerate(); return redirect()->route('dashboard')->with('success','Welcome to GORAID.');
 }
 public function logout(Request $r){Auth::logout();$r->session()->invalidate();$r->session()->regenerateToken();return redirect()->route('home');}
}

<?php
namespace App\Http\Controllers;
use App\Models\Booking;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class DriverController extends Controller {
 private function driver(Request $r){$d=$r->user()->driver;abort_unless($d && $d->is_approved,403,'Driver account is awaiting admin approval.');return $d;}
 public function availability(Request $r){$d=$this->driver($r);$d->update(['is_online'=>$r->boolean('is_online')]);return back()->with('success','Availability updated.');}
 public function accept(Request $r,Booking $booking){$d=$this->driver($r);abort_unless($d->is_online,422,'Go online before accepting rides.');DB::transaction(function()use($r,$booking,$d){$b=Booking::whereKey($booking->id)->lockForUpdate()->firstOrFail();abort_unless($b->status==='pending',409,'This ride is no longer available.');$b->update(['driver_id'=>$d->id,'status'=>'accepted']);$b->histories()->create(['changed_by'=>$r->user()->id,'status'=>'accepted','note'=>'Accepted by driver']);});return back()->with('success','Ride accepted.');}
 public function reject(Request $r,Booking $booking){$this->driver($r);abort_unless($booking->status==='pending',422);$booking->update(['status'=>'rejected']);$booking->histories()->create(['changed_by'=>$r->user()->id,'status'=>'rejected','note'=>'Rejected by driver']);return back()->with('success','Ride rejected.');}
 public function start(Request $r,Booking $booking){$d=$this->driver($r);abort_unless($booking->driver_id===$d->id && $booking->status==='accepted',403);$booking->update(['status'=>'ride_started']);$booking->histories()->create(['changed_by'=>$r->user()->id,'status'=>'ride_started','note'=>'Ride started']);return back()->with('success','Ride started.');}
 public function complete(Request $r,Booking $booking){$d=$this->driver($r);abort_unless($booking->driver_id===$d->id && $booking->status==='ride_started',403);$data=$r->validate(['final_fare'=>'required|numeric|min:0|max:10000000']);$booking->update(['status'=>'completed','final_fare'=>$data['final_fare']]);$booking->histories()->create(['changed_by'=>$r->user()->id,'status'=>'completed','note'=>'Ride completed']);$booking->payments()->create(['amount'=>$data['final_fare'],'method'=>$booking->payment_method,'status'=>'pending']);return back()->with('success','Ride completed. Collect payment from the customer.');}
}

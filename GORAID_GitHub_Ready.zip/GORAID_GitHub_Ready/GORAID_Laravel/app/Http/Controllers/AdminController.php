<?php
namespace App\Http\Controllers;
use App\Models\User; use App\Models\Driver; use App\Models\Booking; use App\Models\Vehicle; use App\Models\VehicleCategory; use App\Models\ContactMessage; use Illuminate\Http\Request;
class AdminController extends Controller {
 public function index(){return view('admin.dashboard',['stats'=>['users'=>User::where('role','customer')->count(),'drivers'=>Driver::count(),'bookings'=>Booking::count(),'active'=>Booking::whereIn('status',['accepted','ride_started'])->count(),'completed'=>Booking::where('status','completed')->count(),'revenue'=>Booking::where('status','completed')->sum('final_fare'),'pending_drivers'=>Driver::where('is_approved',false)->count()],'recent'=>Booking::with('user','category')->latest()->take(8)->get()]);}
 public function bookings(){return view('admin.bookings',['bookings'=>Booking::with('user','category','driver.user')->latest()->paginate(20)]);}
 public function drivers(){return view('admin.drivers',['drivers'=>Driver::with('user','vehicle')->latest()->paginate(20)]);}
 public function approveDriver(Driver $driver){$driver->update(['is_approved'=>true]);return back()->with('success','Driver approved.');}
 public function vehicles(){return view('admin.vehicles',['vehicles'=>Vehicle::with('category')->latest()->get(),'categories'=>VehicleCategory::all()]);}
 public function storeVehicle(Request $r){$d=$r->validate(['vehicle_category_id'=>'required|exists:vehicle_categories,id','name'=>'required|string|max:120','registration_number'=>'required|string|max:80|unique:vehicles,registration_number','capacity'=>'nullable|integer|min:1']);Vehicle::create($d);return back()->with('success','Vehicle added.');}
 public function deleteVehicle(Vehicle $vehicle){$vehicle->delete();return back()->with('success','Vehicle deleted.');}
 public function messages(){return view('admin.messages',['messages'=>ContactMessage::latest()->paginate(20)]);}
 public function fares(){return view('admin.fares',['categories'=>VehicleCategory::all()]);}
 public function updateFares(Request $r){$data=$r->validate(['fares'=>'required|array','fares.*.base_fare'=>'required|numeric|min:0','fares.*.per_km_rate'=>'required|numeric|min:0','fares.*.minimum_fare'=>'required|numeric|min:0']);foreach($data['fares'] as $id=>$fare){VehicleCategory::whereKey($id)->update($fare);}return back()->with('success','Fare settings saved.');}
}

<?php
namespace App\Http\Controllers;
use App\Models\Booking;
use App\Models\BookingStatusHistory;
use App\Models\VehicleCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
class BookingController extends Controller {
 public function create(){return view('bookings.create',['categories'=>VehicleCategory::where('is_active',true)->get()]);}
 public function store(Request $r){
  $d=$r->validate(['vehicle_category_id'=>'required|exists:vehicle_categories,id','pickup_location'=>'required|string|max:255','dropoff_location'=>'required|string|max:255','pickup_date'=>'required|date|after_or_equal:today','pickup_time'=>'required|date_format:H:i','distance_km'=>'required|numeric|min:0.1|max:2000','payment_method'=>['required',Rule::in(['cash','jazzcash','easypaisa'])],'notes'=>'nullable|string|max:1000']);
  $cat=VehicleCategory::findOrFail($d['vehicle_category_id']);
  $fare=max((float)$cat->minimum_fare,(float)$cat->base_fare+((float)$d['distance_km']*(float)$cat->per_km_rate));
  $booking=Booking::create([...$d,'booking_code'=>'GR-'.strtoupper(Str::random(8)),'user_id'=>$r->user()->id,'estimated_fare'=>$fare,'status'=>'pending','payment_status'=>'unpaid']);
  $booking->histories()->create(['changed_by'=>$r->user()->id,'status'=>'pending','note'=>'Booking created']);
  return redirect()->route('bookings.show',$booking)->with('success','Ride request submitted. Pay after your ride is completed.');
 }
 public function show(Request $r,Booking $booking){
  abort_unless($r->user()->role==='admin'||$booking->user_id===$r->user()->id||($r->user()->driver && $booking->driver_id===$r->user()->driver->id),403);
  return view('bookings.show',['booking'=>$booking->load('category','driver.user','histories')]);
 }
 public function cancel(Request $r,Booking $booking){
  abort_unless($booking->user_id===$r->user()->id,403);
  abort_unless(in_array($booking->status,['pending','accepted'],true),422,'This ride can no longer be cancelled.');
  $d=$r->validate(['cancel_reason'=>'required|string|max:500']);
  $booking->update(['status'=>'cancelled','cancel_reason'=>$d['cancel_reason']]);
  $booking->histories()->create(['changed_by'=>$r->user()->id,'status'=>'cancelled','note'=>$d['cancel_reason']]);
  return back()->with('success','Ride cancelled.');
 }
}

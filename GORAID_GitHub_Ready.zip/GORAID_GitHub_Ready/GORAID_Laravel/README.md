# GORAID | Laravel 12 Ride Booking Platform

A Laravel 12 + MySQL starter application for Pakistan-wide passenger and cargo transport bookings.

## Requirements
- PHP 8.2+
- Composer 2
- MySQL 8 / MariaDB
- XAMPP or equivalent
- Node.js is optional for this version because Bootstrap is loaded from CDN.

## Install on Windows / XAMPP
1. Extract `GORAID_Laravel_Project.zip` into `C:\xampp\htdocs\GORAID`.
2. Open CMD in that folder.
3. Run:
   ```bash
   composer install
   copy .env.example .env
   php artisan key:generate
   ```
4. In phpMyAdmin create a database named `goraid` with `utf8mb4_unicode_ci`.
5. Update `.env` with your MySQL username/password.
6. Run:
   ```bash
   php artisan migrate --seed
   php artisan storage:link
   php artisan serve
   ```
7. Open `http://127.0.0.1:8000`.

## Seeded logins
- Admin: `admin@goraid.pk` / `Password@123`
- Driver: `driver@goraid.pk` / `Password@123`
- Customer: `customer@goraid.pk` / `Password@123`

Change all seeded passwords immediately on a real deployment.

## Separate SQL
Import `GORAID_Database.sql` through phpMyAdmin if you want the schema/data as a standalone SQL export. Do not import the SQL and then run migrations on the same database unless you first empty it.

## Important configuration
- Map integration: set `GOOGLE_MAPS_API_KEY` in `.env`. The booking workflow currently accepts manually selected location text; live Google Places autocomplete and route distance require a valid key and are not enabled in this starter.
- Online payments: Cash After Ride is the working default. JazzCash/Easypaisa are stored as configurable methods, but gateway credentials and signed callback verification must be added before accepting online payments.
- Fare estimate uses admin-configured base fare + per-kilometre rate. Distance is entered/confirmed in kilometres in this starter; do not treat it as a live map measurement.
- Driver document uploads are stored privately in `storage/app/private` where configured. Add production-grade document review/storage policy before launch.

## Current scope
Included: registration/login, role-aware dashboards, driver approval and online toggle, vehicle/category management, booking creation, driver accept/reject/start/complete actions, post-completion payment recording, cancellation, contact messages, fare settings, Pakistan region/city/area seed data, responsive Bootstrap UI.

Before public launch, configure real map and payment integrations, mail/SMS notifications, rate limiting, backups, HTTPS, production storage, and run a full security/acceptance test.

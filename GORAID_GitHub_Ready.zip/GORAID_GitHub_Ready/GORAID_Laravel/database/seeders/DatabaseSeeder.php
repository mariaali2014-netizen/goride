<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User; use App\Models\Driver; use App\Models\VehicleCategory; use App\Models\Province; use App\Models\City; use App\Models\Location;
class DatabaseSeeder extends Seeder {
 public function run(): void {
  User::firstOrCreate(['email'=>'admin@goraid.pk'],['name'=>'GORAID Admin','phone'=>'03000000000','password'=>Hash::make('Password@123'),'role'=>'admin']);
  $driver=User::firstOrCreate(['email'=>'driver@goraid.pk'],['name'=>'Demo Driver','phone'=>'03001112222','password'=>Hash::make('Password@123'),'role'=>'driver']);
  Driver::firstOrCreate(['user_id'=>$driver->id],['is_approved'=>true,'is_online'=>true]);
  User::firstOrCreate(['email'=>'customer@goraid.pk'],['name'=>'Demo Customer','phone'=>'03003334444','password'=>Hash::make('Password@123'),'role'=>'customer']);
  $cats=[
   ['Bike','bike',180,35,180,1],['Premium Bike','premium-bike',250,45,250,1],
   ['Standard Riksha','standard-riksha',250,55,250,3],['Loader Riksha','loader-riksha',500,85,500,500],
   ['Economy Car','economy-car',450,75,450,4],['Business Car','business-car',800,110,800,4],['Premium Car','premium-car',1200,150,1200,4],['Family Car','family-car',900,120,900,7],
   ['Suzuki Pickup','suzuki-pickup',900,130,900,800],['Shehzore','shehzore',1500,180,1500,1500],['Mazda','mazda',2500,250,2500,3000],
   ['Heavy Truck','heavy-truck',5000,450,5000,10000],['Container Truck','container-truck',8000,600,8000,20000],['Trailer','trailer',10000,750,10000,30000],['Dump Truck','dump-truck',7000,550,7000,18000],['Cargo Truck','cargo-truck',3000,300,3000,5000]
  ];
  foreach($cats as [$name,$slug,$base,$rate,$min,$capacity]) VehicleCategory::firstOrCreate(['slug'=>$slug],['name'=>$name,'base_fare'=>$base,'per_km_rate'=>$rate,'minimum_fare'=>$min,'capacity'=>$capacity,'description'=>'GORAID '.$name.' transport service']);
  $regions=['Sindh'=>['Karachi','Hyderabad','Sukkur','Larkana','Nawabshah'],'Punjab'=>['Lahore','Rawalpindi','Faisalabad','Multan','Gujranwala'],'Khyber Pakhtunkhwa'=>['Peshawar','Mardan','Abbottabad','Swat'],'Balochistan'=>['Quetta','Gwadar','Turbat'],'Islamabad Capital Territory'=>['Islamabad'],'Gilgit-Baltistan'=>['Gilgit','Skardu'],'Azad Jammu & Kashmir'=>['Muzaffarabad','Mirpur']];
  foreach($regions as $province=>$cities){$p=Province::firstOrCreate(['name'=>$province]);foreach($cities as $cityName){$city=City::firstOrCreate(['province_id'=>$p->id,'name'=>$cityName]);if($cityName==='Karachi'){foreach(['Gulshan-e-Iqbal','Gulistan-e-Johar','North Nazimabad','Nazimabad','Orangi Town','Saddar','Clifton','DHA','Korangi','Malir','Landhi','Liaquatabad','Federal B Area','Shah Faisal Colony','SITE Area','Baldia Town','Kemari','Lyari','New Karachi'] as $area) Location::firstOrCreate(['city_id'=>$city->id,'name'=>$area],['location_type'=>'area']);}}}
 }
}
